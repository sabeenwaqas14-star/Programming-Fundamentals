#include<iostream>
using namespace std;
main ()
{
	cout<<"Enter number of hours:";
	int hours;
	cin>>hours;

	int seconds;
	seconds = hours * 3600;
	
	cout<<hours<<"hours are equivalent to ";
	cout<<seconds;
}