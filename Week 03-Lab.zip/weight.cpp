#include<iostream>
using namespace std;
main()
{
	int kilograms;
	float a=2.205;
	int pounds;
	cout<< "Enter your weight:";	
	cin >> kilograms;
	pounds = kilograms * a;
	cout<< "your weight in..";
	cout<< pounds;
	
}