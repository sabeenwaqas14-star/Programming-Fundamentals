#include<iostream>
using namespace std;
main()
{
	int length;
	int width;
	int Area;
	cout<< "Enter length:";
	cin>> length;
	cout<< "Enter width:";
	cin>> width;
	Area = length * width;
	cout<< "Area= ";
	cout<<Area;
}