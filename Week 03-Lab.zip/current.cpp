#include<iostream>
using namespace std;
main()
{
	int Q,t,I;
	cout<<"Enter charge:";
	cin>>Q;

	cout<<"Enter time:";
	cin>>t;
	I = Q/t;
	cout<<"Current:";
	cout<<I;
}