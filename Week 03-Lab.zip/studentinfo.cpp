#include<iostream>
using namespace std;
main()
{
	int age;
	string name;
	float aggregate;

	cout<<"enter age";
	cin>>age;
	cout<<"Enter name ";
	getline(cin>>ws,name);
	cout<<"enter aggregate";
	cin>>aggregate;

	cout<<"name" <<name<<endl;
	cout<<"age is "<<age<<endl;
	cout<<"aggregate is "<<aggregate;


}