#include<iostream>
using namespace std;
main()
{
	int wins,draws,losses;
	string namect;

	cout<<"Enter the name of the cricket team:";
	cin>> namect;

	cout<<"Enter the number of wins:";
	cin>>wins;

	cout<<"Enter the number of draws:";
	cin>>draws;

	cout<<"Enter the number of losses:";
	cin>>losses;

	int points;
	points = (wins*3) + (draws*1) + (losses*0);
	
	cout<<namect<<" has obtained "<<points<<" points in Asia Cup Tournament";

}