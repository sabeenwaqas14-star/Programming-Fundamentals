#include<iostream>
using namespace std;
main()
{
	string name;
	int mm,im,ecatm;
	float agg;
	cout<<"Enter name:";
	getline(cin, name);

	cout<<"Enter matriculation marks:";
	cin>>mm;

	cout<<"Enter intermediate marks:";
	cin>>im;

	cout<<"Enter ecat marks:";
	cin>>ecatm;
	
	agg = (mm*10/1100)+(im*50/550)+(ecatm*40/400);
	cout<<"Your aggregate in UET is:";
	cout<<agg;
}