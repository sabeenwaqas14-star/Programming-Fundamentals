#include<iostream>
using namespace std;
main()
{
	int rupee = 200;
	int inputValue = 10;
	int convertedValue;
	cout << "$1= " << rupee << "rupees" <<endl;
	convertedValue = rupee * inputValue;
	cout << convertedValue;
}