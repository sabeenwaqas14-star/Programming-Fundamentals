#include<iostream>
using namespace std;
main()
{
	cout<<"Enter voltage(in Volts):";
	float V;
	cin>>V;

	cout<<"Enter current(in Amperes):";
	float I;
	cin>>I;

	float P;
	P = V * I;
	cout<<"The power is:"<<P;
}