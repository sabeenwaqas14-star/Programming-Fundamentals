#include<iostream>
using namespace std;
main()
{
	string name="Sabeen";
	cout<< name;
}