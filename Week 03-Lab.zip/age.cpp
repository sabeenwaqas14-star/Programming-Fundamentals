#include<iostream>
using namespace std;
main()
{
	cout<<"Enter your age in years:";
	int ageinyears;
	cin>>ageinyears;

	int ageindays;
	ageindays = ageinyears * 365;
	
	cout<<"Your age in days is "<<ageindays;
}