#include<iostream>
using namespace std;
main()
{
	cout<<"Enter the current world population:";
	int cwp;
	cin>>cwp;

	cout<<"Enter the monthly birth rate (number of births per month):";
	int mbr;
	cin>>mbr;

	int popthree;
	popthree = (360*mbr)+cwp;

	cout<<"The population in three decades will be "<<popthree;
	
}