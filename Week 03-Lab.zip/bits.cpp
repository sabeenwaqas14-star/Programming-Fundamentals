#include<iostream>
using namespace std;
main()
{	
	cout<<"data in megabytes:";
	int megabytes;
	cin>>megabytes;

	long long int bits;
	bits = megabytes * 1000000 * 8;
	
	cout<<"total bits:";
	cout<<bits;
}