#include<iostream>
using namespace std;
main()
{
	int a,b;
	cout << "tell the speed of car:";
	cin>> a;
	if(a>100)
	cout << "you are challaaned:";
	else
	cout << "you are going good:";
	
	
	
	
	
	
	
}