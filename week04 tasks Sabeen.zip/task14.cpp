#include <iostream>

using namespace std;

int main() {
    
    
    float REDP = 2.00;
    float WHITEP = 4.10;
    float TULIPP = 2.50;
    

    float LIMIT = 200.00;
    float RATE = 0.20;
    

    int rnum;
    int wnum;
    int tnum;
    

    float originalp;
    float finalp;
    
    cout << "tell the number of red rose: ";
    cin >> rnum;
    
    cout << "Tell the number of White Rose: ";
    cin >> wnum;
    
    cout << "Tell the number of Tulips : ";
    cin >> tnum;
    
    originalp = (rnum * REDP) + 
                 (wnum * WHITEP) + 
                 (tnum * TULIPP);
    
    finalp = originalp;
    
    if (originalp > LIMIT) {
        finalp = originalp * (1.0 - RATE);
    }
    
    cout << "\nReal price: " << originalp << endl;
    cout << "After Discount: " << finalp << endl;
    
    cout << "Program terminated" << endl;
    
}
