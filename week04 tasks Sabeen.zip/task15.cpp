#include <iostream>
#include <cmath>
using namespace std;

const int DAYS_IN_YEAR = 365;
const int SLEEP_NORM_MINUTES = 30000;
const int WORKING_DAY_PLAY = 63;
const int HOLIDAY_PLAY = 127;
const int MINUTES_PER_HOUR = 60;

void pet(int holidays) {
    int working_days = DAYS_IN_YEAR - holidays;

    long long total_holiday_play = (long long)holidays * HOLIDAY_PLAY;
    long long total_working_day_play = (long long)working_days * WORKING_DAY_PLAY;
    long long total_play_time = total_holiday_play + total_working_day_play;

    long long difference = SLEEP_NORM_MINUTES - total_play_time;

    long long abs_difference = std::abs(difference);
    long long diff_hours = abs_difference / MINUTES_PER_HOUR;
    long long diff_minutes = abs_difference % MINUTES_PER_HOUR;

    cout << "\n--- Result ---" <<endl;
    cout << "Total Play Time: " << total_play_time << " minutes." <<endl;
    cout << "Sleep Norm: " << SLEEP_NORM_MINUTES << " minutes." <<endl;

    if (difference >= 0) {
        cout << "\nTom can **sleep well!**" <<endl;
        cout << "He is under the norm by: " << diff_hours << " hours and " 
                  << diff_minutes << " minutes." <<endl;
    } else {
        cout << "\nTom **CANNOT sleep well!**" <<endl;
        cout << "He is over the norm by: " << diff_hours << " hours and " 
                  << diff_minutes << " minutes." << endl;
    }
}

int main() {
    int holidays;

    cout << "Enter the number of holidays: ";
    if (!(cin >> holidays)) {
        cerr << "Invalid input. Please enter a number." << endl;
        return 1;
    }

    pet(holidays);

}