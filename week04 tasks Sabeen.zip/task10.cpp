#include <iostream>
#include <string>
#include <cctype>
#include <iomanip>

using namespace std;

void calculateFinalPrice(string country, double price) {
    double discountRate = 0.0;

    for (char &c : country) {
        c = tolower(c);
    }

    if (country == "pakistan") {
        discountRate = 0.05;
    } else if (country == "ireland") {
        discountRate = 0.10;
    } else if (country == "india") {
        discountRate = 0.20;
    } else if (country == "england") {
        discountRate = 0.30;
    } else if (country == "canada") {
        discountRate = 0.45;
    } else {
        cout << "\nError: The country name '" << country << "' is not eligible for a discount." << endl;
        return; 
    }

    double discountAmount = price * discountRate;
    double finalPrice = price - discountAmount;
    
    cout << fixed << setprecision(2);
    cout << "\n--- Discount Details ---" << endl;
    cout << "Original Price: $" << price << endl;
    cout << "Discount Rate: " << discountRate * 100.0 << "%" << endl;
    cout << "Discount Amount: $" << discountAmount << endl;
    cout << "Final Price: $" << finalPrice << endl;
    cout << "------------------------" << endl;
}

int main() {
    string travelCountry;
    double ticketPrice;

    cout << "======================================" << endl;
    cout << "   Airline Ticket Discount System     " << endl;
    cout << "======================================" << endl;

    cout << "Enter the destination country (e.g., Pakistan, India): ";
    cin >> travelCountry;

    cout << "Enter the original ticket price ($): ";
    
    if (!(cin >> ticketPrice) || ticketPrice <= 0) {
        cout << "Invalid price entered. Exiting." << endl;
        return 1;
    }

    calculateFinalPrice(travelCountry, ticketPrice);

}
