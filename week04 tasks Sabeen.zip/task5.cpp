#include <iostream>
#include <windows.h> 
using namespace std;

const int LETTER_HEIGHT = 9;

const int LETTER_WIDTH = 12;

const int START_X = 15;

const int START_Y = 2; 

void gotoxy(int x, int y) {
    COORD coordinates; 
    coordinates.X = x; 
    coordinates.Y = y; 
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
}

void drawLetter(const string letterArt[], int startX, int startY) {
    for (int y = 0; y < LETTER_HEIGHT; ++y) {
        gotoxy(startX, startY + y);
        cout << letterArt[y];
    }
}


void printS(int startX, int startY) {
    string L_S[LETTER_HEIGHT] = {
        "############",
        "##          ",
        "##          ",
        "############",
        "          ##",
        "          ##",
        "          ##",
        "          ##",
        "############"
    };
    drawLetter(L_S, startX, startY);
}

void printA(int startX, int startY) {
    string L_A[LETTER_HEIGHT] = {
        "############",
        "##         ##",
        "##         ##",
        "##         ##",
        "############ ",
        "##         ##",
        "##         ##",
        "##         ##",
        "##         ##"
    };
    drawLetter(L_A, startX, startY);
}


void printB(int startX, int startY) {
    string L_B[LETTER_HEIGHT] = {
        "############", 
        "##        ##", 
        "##        ##", 
        "##        ##", 
        "##########", 
        "##        ##", 
        "##        ##", 
        "##        ##", 
        "############"  
    };
drawLetter(L_B, startX, startY);
}
void printE(int startX, int startY) {
    string L_E[LETTER_HEIGHT] = {
        "############", 
        "##          ", 
        "##          ", 
        "##          ", 
        "############", 
        "##          ", 
        "##          ", 
        "##          ", 
        "############"  
    };
drawLetter(L_E, startX, startY);
}
void printN(int startX, int startY) {
    string L_N[LETTER_HEIGHT] = {
        "####         ##", 
        "##  ##       ##", 
        "##   ##      ##", 
        "##    ##     ##", 
        "##     ##    ##", 
        "##      ##   ##", 
        "##       ##  ##", 
        "##        ## ##", 
        "##         ####"  
    };
    drawLetter(L_N, startX, startY);
}


void printBigNameVertical(const string& name) {
    int currentY = START_Y;
    int currentX = START_X; 
    for (char c : name) {
        switch (toupper(c)) {
            case 'S': printS(currentX, currentY); break;
            case 'A': printA(currentX, currentY); break;
            case 'B': printB(currentX, currentY); break;
            case 'E': printE(currentX, currentY); break;
	    case 'N': printN(currentX, currentY); break;
            default: break; 
        }
        
        currentY += LETTER_HEIGHT + 1; 
    }
}


int main()
 {
    
    system("cls"); 
    printBigNameVertical("SABEN");
    gotoxy(0, START_Y + (6 * (LETTER_HEIGHT + 1)) + 2);
    cout << "The name \"SABEN\" is printed vertically. Press Enter to exit." << endl;
    
    cin.get();
}
