#include <iostream>
#include <string>

std::string possibleBonus(int a, int b) {
    int distance = b - a;

    if (distance >= 1 && distance <= 6) {
        std::cout << "true" << std::endl;
        return "true";
    } else {
        std::cout << "false" << std::endl;
        return "false";
    }
}

int getPositiveInt(const std::string& prompt) {
    int value;
    while (true) {
        std::cout << prompt;
        if (std::cin >> value) {
            if (value > 0) {
                return value;
            } else {
                std::cout << "Error: Please enter a positive integer." << std::endl;
            }
        } else {
            std::cout << "Error: Invalid input. Please enter an integer." << std::endl;
            std::cin.clear();
            std::cin.ignore(10000, '\n');
        }
    }
}


int main() {
    int my_position;
    int friend_position;

    my_position = getPositiveInt("Enter your current position (a): ");

    while (true) {
        friend_position = getPositiveInt("Enter your friend's position (b): ");
        if (friend_position > my_position) {
            break;
        } else {
            std::cout << "As per the problem rules, your friend's position must be ahead of yours (b > a)." << std::endl;
        }
    }
    
    std::cout << "\n--- Result ---" << std::endl;
    std::cout << "Can you reach position " << friend_position << " from " 
              << my_position << " in one roll (1-6)? " << std::endl;
    
    possibleBonus(my_position, friend_position);
}