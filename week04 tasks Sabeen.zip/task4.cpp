#include<iostream>
#include<windows.h>
using namespace std;

void Maze();
void gotoxy(int x,int y);
void MovePlayer(int x,int y);

main()
{
	int x=5,y=5;
	system("cls");
	Maze();
	while(true)
	{
	MovePlayer(x,y);
	x = x + 1;
	if(x == 21) {
	x = 4;
	}
}
}
void MovePlayer(int x,int y)
{
	gotoxy(x,y);
	cout<<"P";
	Sleep(100);
	gotoxy(x,y);
	cout<<" ";
}
void Maze()
{
        cout<<"$$$$$$$$$$$$$$$$$$$"<<endl;
	cout<<"$		  $"<<endl;
	cout<<"$		  $"<<endl;
	cout<<"$		  $"<<endl;
	cout<<"$		  $"<<endl;
	cout<<"$		  $"<<endl;
	cout<<"$		  $"<<endl;
	cout<<"$$$$$$$$$$$$$$$$$$$"<<endl;
}
void gotoxy(int x,int y)
{
	COORD coordinates;
	coordinates.X = x;
	coordinates.Y = y;
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
}