#include <iostream>
#include <windows.h> 
using namespace std;

void gotoxy(int x, int y);
void printMaze();


void gotoxy(int x, int y) {
    COORD coordinates; 
    coordinates.X = x; 
    coordinates.Y = y; 
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coordinates);
}

void printMaze() {
    
    cout << "#####################" << endl; 
    cout << "#                   #" << endl; 
    cout << "#                   #" << endl; 
    cout << "#                   #" << endl; 
    cout << "#                   #" << endl; 
    cout << "#                   #" << endl; 
    cout << "#                   #" << endl; 
    cout << "#####################" << endl; 
}

int main() {
    
    system("cls"); 
    printMaze();

    
    int playerX = 5;      
    int playerY = 1;      
    int directionY = 1;   
    
    
    const int TOP_WALL_Y = 1;
    const int BOTTOM_WALL_Y = 6;
    const int SPEED_MS = 100; 

    
    while(true) {
        
        
        gotoxy(playerX, playerY);
        cout << " ";

        
        playerY += directionY;

        
        if (playerY >= BOTTOM_WALL_Y) {
            
            playerY = BOTTOM_WALL_Y; 
            directionY = -1;
        } else if (playerY <= TOP_WALL_Y) {
            
            playerY = TOP_WALL_Y; 
            directionY = 1;
        }

        
        gotoxy(playerX, playerY);
        cout << "P"; 

        
        Sleep(SPEED_MS); 
    }
    
     
}
