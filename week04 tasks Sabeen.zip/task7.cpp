#include <iostream>
#include <string>
#include <iomanip> 

using namespace std;

void printMenu();
float calculateAggregate(string name, float matricMarks, float interMarks, float ecatMarks);
void compareMarks(string nameStd1, float ecatMarksStd1, string nameStd2, float ecatMarksStd2);

void printMenu() {
    cout << "==========================================================" << endl;
    cout << "||        UNIVERSITY ADMISSION MANAGEMENT SYSTEM        ||" << endl;
    cout << "==========================================================" << endl;
    cout << "|| 1. Calculate Aggregate Score                         ||" << endl;
    cout << "|| 2. Compare ECAT Scores for Roll Number Priority      ||" << endl;
    cout << "==========================================================" << endl;
}

float calculateAggregate(string name, float matricMarks, float interMarks, float ecatMarks) {
    
    
    const float MAX_MATRIC = 1100.0f;
    const float MAX_INTER = 550.0f;
    const float MAX_ECAT = 400.0f;
    const float WEIGHT_MATRIC = 30.0f;
    const float WEIGHT_INTER = 30.0f;
    const float WEIGHT_ECAT = 40.0f;

    
    float matricContribution = (matricMarks / MAX_MATRIC) * WEIGHT_MATRIC;
    float interContribution = (interMarks / MAX_INTER) * WEIGHT_INTER;
    float ecatContribution = (ecatMarks / MAX_ECAT) * WEIGHT_ECAT;
    
    
    float finalAggregate = matricContribution + interContribution + ecatContribution;

    
    cout << fixed << setprecision(2);
    cout << "\n--- Aggregate Result ---" << endl;
    cout << "Student: " << name << endl;
    cout << "Matric Contribution (30%): " << matricContribution << endl;
    cout << "Inter Contribution (30%):  " << interContribution << endl;
    cout << "ECAT Contribution (40%):   " << ecatContribution << endl;
    cout << "------------------------------------" << endl;
    cout << "Final Aggregate Score:     " << finalAggregate << "%" << endl;
    cout << "------------------------------------" << endl;

    return finalAggregate;
}

void compareMarks(string nameStd1, float ecatMarksStd1, string nameStd2, float ecatMarksStd2) {
    cout << "\n--- ECAT Comparison for Roll Number Priority ---" << endl;
    cout << "Student 1: " << nameStd1 << " (" << ecatMarksStd1 << ")" << endl;
    cout << "Student 2: " << nameStd2 << " (" << ecatMarksStd2 << ")" << endl;
    cout << "------------------------------------------------" << endl;

    if (ecatMarksStd1 > ecatMarksStd2) {
        
        cout << nameStd1 << " has higher ECAT marks. They will receive the first roll number." << endl;
    } else if (ecatMarksStd2 > ecatMarksStd1) {
        
        cout << nameStd2 << " has higher ECAT marks. They will receive the first roll number." << endl;
    } else {
        
        cout << "Both students have equal ECAT marks. Tie-breaking measures (e.g., Inter marks) will be needed." << endl;
    }
}

int main() {
    
    
    string name1;
    float matric1, inter1, ecat1;

    
    string name2;
    float matric2, inter2, ecat2;

    
    printMenu();

    cout << "\nPlease enter details for Student 1 (for Aggregate Calculation):" << endl;
    cout << "Enter Name: ";
    getline(cin, name1);
    cout << "Enter Matric Marks (out of 1100): ";
    cin >> matric1;
    cout << "Enter Intermediate Marks (out of 550): ";
    cin >> inter1;
    cout << "Enter ECAT Marks (out of 400): ";
    cin >> ecat1;

    
    cin.ignore(10000, '\n'); 
    cout << "\n\nPlease enter details for Student 2 (for ECAT Comparison):" << endl;
    cout << "Enter Name: ";
    getline(cin, name2);
    
    
    cout << "Enter ECAT Marks (out of 400): ";
    cin >> ecat2;
    
    
    calculateAggregate(name1, matric1, inter1, ecat1);

    
    compareMarks(name1, ecat1, name2, ecat2);
    
    cout << "\nProgram finished. Press Enter to exit." << endl;
    cin.get(); 
    cin.get();
}
