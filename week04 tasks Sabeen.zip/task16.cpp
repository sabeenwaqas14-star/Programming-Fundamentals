#include <iostream>
#include <string>
using namespace std;

const int SHEETS_PER_ROLL = 500;
const int SHEETS_PER_PERSON_DAY = 57;
const int QUARANTINE_DAYS = 14;

void tpChecker(int people, int tp) {
    long long total_sheets = (long long)tp * SHEETS_PER_ROLL;
    
    int daily_consumption = people * SHEETS_PER_PERSON_DAY;

    if (daily_consumption <= 0) {
        cout << "Your TP supply is infinite (or invalid household size)." <<endl;
        return;
    }
    
    int duration_days = total_sheets / daily_consumption;

    cout << "\n--- TP Supply Analysis ---" <<endl;
    cout << "Household size: " << people << " people" <<endl;
    cout << "TP Rolls: " << tp << " rolls" <<endl;
    cout << "Duration needed: " << QUARANTINE_DAYS << " days" <<endl;
    cout << "--------------------------" <<endl;

    cout << "Your TP will last " << duration_days << " days, ";

    if (duration_days >= QUARANTINE_DAYS) {
        cout << "no need to panic!" <<endl;
    } else {
        cout << "buy more!" <<endl;
    }
}

int getPositiveInt(const std::string& prompt) {
	int value;
    while (true) {
        cout << prompt;
        if (cin >> value) {
            if (value > 0) {
                return value;
            } else {
                cout << "Error: Value must be positive." << endl;
            }
        } else {
            cout << "Error: Invalid input. Please enter an integer." << endl;
            cin.clear();
            cin.ignore(10000, '\n');
        }
    }
}

main() {
    int people_count = getPositiveInt("Enter the number of people in the household: ");
    int rolls_count = getPositiveInt("Enter the number of TP rolls you have: ");

    tpChecker(people_count, rolls_count);

}