#include <iostream>
#include <string>

using namespace std;

void isEqual(int num1, int num2) {
    if (num1 == num2) {
        cout << "true" << endl;
    } else {
        cout << "false" << endl;
    }
}

int main() 
{
    int val1;
    int val2;

    cout << "-----------------------------------" << endl;
    cout << "       Integer Equality Check      " << endl;
    cout << "-----------------------------------" << endl;

    cout << "Enter the first integer: ";
    cin >> val1;

    cout << "Enter the second integer: ";
    cin >> val2;

    cout << "\nResult (IsEqual(" << val1 << ", " << val2 << ")): ";
    
    isEqual(val1, val2);

    cout << "\nTesting provided cases:" << endl;
    
    cout << "IsEqual(5, 6) -> ";
    isEqual(5, 6); 

    cout << "IsEqual(1, 1) -> ";
    isEqual(1, 1);

    cout << "IsEqual(36, 35) -> ";
    isEqual(36, 35);

}
