#include <iostream>
#include <string>
using namespace std;

void reverseBooleanString(string input) {
    string lowerInput = input;
    for (char &c : lowerInput) {
        c = tolower(c);
    }

    if (lowerInput == "true") {
        cout << "false" << endl;
    } else if (lowerInput == "false") {
        cout << "true" << endl;
    } else {
        cout << "Error: Invalid input string. Please enter 'true' or 'false'." << endl;
    }
}

int main() {
    string userInput;

    cout << "-----------------------------------" << endl;
    cout << "      Boolean String Reverser      " << endl;
    cout << "-----------------------------------" << endl;

    cout << "Enter 'true' or 'false': ";
    cin >> userInput;

    cout << "\nResult (Reverse(" << userInput << ")): ";
    
    reverseBooleanString(userInput);

    cout << "\nTesting provided cases:" << endl;
    
    cout << "Reverse(\"true\") -> ";
    reverseBooleanString("true"); 

    cout << "Reverse(\"false\") -> ";
    reverseBooleanString("false");
}
