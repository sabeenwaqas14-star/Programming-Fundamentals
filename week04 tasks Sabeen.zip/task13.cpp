#include<iostream>
using namespace std;
int main ()
{
	int m , h ;
	cout <<"Enter hours and minutes :";
	cin>>h>>m;
	h = h*60;
	if (h > m)
	cout <<h/60;
	else
	cout <<m;
}